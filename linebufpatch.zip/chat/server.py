import socket
import threading

import sys

def receive_messages(conn):
    while True:
        try:
            msg = conn.recv(1024).decode('utf-8')
            if not msg:
                break
            sys.stdout.write('\r' + ' ' * 80 + '\r')
            print(f"JPL: {msg}")
            print("- ", end='', flush=True)
        except:
            break

    print("connection lost.")
    conn.close()

def main():
    host = '0.0.0.0'
    port = 54321

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(1)

    print(f"[+] 서버 실행 중... 포트 {port}")
    conn, addr = s.accept()
    print(f"TEXT BASED [INCOMING MESSAGE]\nv.0.928\n---------------------------------------------------------- {addr}")

    # 수신 스레드 시작
    threading.Thread(target=receive_messages, args=(conn,), daemon=True).start()

    # 메시지 전송 루프
    try:
        while True:
            msg = input("- ")
            if msg.lower() == "exit":
                print("채팅 종료")
                break
            conn.send(msg.encode('utf-8'))  # UTF-8 인코딩
    except:
        print("[!] 오류로 채팅 종료")
    finally:
        conn.close()
        s.close()

if __name__ == "__main__":
    main()

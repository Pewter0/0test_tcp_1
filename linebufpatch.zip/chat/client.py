import socket
import threading

import sys

def receive_messages(sock):
    while True:
        try:
            msg = sock.recv(1024).decode('utf-8')
            if msg:
                # 현재 입력 줄 지우기
                sys.stdout.write('\r' + ' ' * 80 + '\r')
                print(f"[Server]: {msg}")
                # 입력 프롬프트 다시 출력
                print("You: ", end='', flush=True)
        except:
            print("\n[오류] 서버로부터 메시지를 받는 중 오류 발생.")
            break
def main():
    host = input("서버 IP 입력: ")  # 예: 127.0.0.1
    port = 54321

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))

    threading.Thread(target=receive_messages, args=(s,), daemon=True).start()

    try:
        while True:
            msg = input("You: ")
            if msg.lower() == "exit":
                print("채팅을 종료합니다.")
                break
            s.send(msg.encode('utf-8'))
    except:
        print("오류로 인해 채팅이 종료되었습니다.")
    finally:
        s.close()

if __name__ == "__main__":
    main()
